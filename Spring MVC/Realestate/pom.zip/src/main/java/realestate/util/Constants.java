package realestate.util;

public final class Constants {
    
    public static String MESSAGE_VALIDATION_ERROR = "Something went wrong!";
}
